sudo python3 view.py
